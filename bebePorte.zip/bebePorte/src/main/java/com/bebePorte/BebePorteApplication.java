package com.bebePorte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BebePorteApplication {

	public static void main(String[] args) {
		SpringApplication.run(BebePorteApplication.class, args);
	}

}
